

public class main 
{

	public static void main(String[] args) {
		long tme1,tme2;
		LongInteger A = new LongInteger("2222");
		//SLL=4580060, Array=4916993
		LongInteger B = new LongInteger("99999999");
		//SLL=57710, Array=54364
		LongInteger C = new LongInteger("-246813575732");
		//SLL=29254, Array=19664
		LongInteger D = new LongInteger("180270361023456789");
		//SLL=25182, Array=27588
		LongInteger E = new LongInteger("1423550000000010056810000054593452907711568359");
		//SLL=46228, Array=55617
		LongInteger F = new LongInteger("-350003274594847454317890");
		//SLL=33431, Array=32223
		LongInteger G = new LongInteger("29302390234702973402973420937420973420937420937234872349872934872893472893749287423847");
		//SLL=70540, Array=74858
		LongInteger H = new LongInteger("-98534342983742987342987339234098230498203894209928374662342342342356723423423");
		//SLL=102396, Array=110828
		LongInteger I = new LongInteger("8436413168438618351351684694835434894364351846843435168484351684684315384684313846813153843135138413513843813513813138438435153454154515151513141592654543515316848613242587561516511233246174561276521672162416274123076527612");
		//SLL=304009, Array=893498
		LongInteger J = B.add(C);
		//SLL=84576, Array=92452
		LongInteger K = C.add(D);
		//SLL=19599, Array=22722
		LongInteger L = I.add(I);
		//SLL=777864, Array=1459137
		LongInteger M = A.add(I);
		//SLL=114236, Array=77058
		LongInteger N = B.add(K);
		//SLL=12767, Array=13109
		LongInteger O = A.subtract(D);
		//SLL=40520, Array=76040
		LongInteger P = C.subtract(D);
		//SLL=36290, Array=40939
		LongInteger Q = D.subtract(C);
		//SLL=16927, Array=17293
		LongInteger R = L.subtract(L);
		//SLL=473421, Array=269162
		LongInteger S = P.subtract(O);
		//SLL=34000, Array=37446
		LongInteger T = N.subtract(Q);
		//SLL=44647, Array=55233
		LongInteger U = A.multiply(D);
		//SLL=57523, Array=92364
		LongInteger V = B.multiply(C);
		//SLL=194648, Array=55105
		LongInteger W = D.multiply(D);
		//SLL=191199, Array=123040
		LongInteger X = O.multiply(I);
		//SLL=1642841, Array=2494449
		LongInteger Y = J.multiply(P);
		//SLL=41977, Array=59013
		LongInteger Z = M.multiply(N);
		//SLL=183411, Array=202330


		final LongInteger[] arr = {A , B , C , D , E , F , G , H , I};
		final LongInteger[] arr2 = {J , K , L , M , N , O , P , Q , R , S ,T , U , V , W , X , Y , Z};
		char alph[] = {'A','B','C','D','E','F','G','H','I'};
		
		char x,y;

		LongInteger z1,z2;

		System.out.println("Step 1 Test Cases:");
		for(int i=0; i<9; i++)
		{
			z1=arr[i];
			System.out.print(alph[i]+" = ");
			z1.output();
			System.out.println();
			System.out.print("Values at all positions : ");
			z1.testcase2();
			System.out.println();
			System.out.println("is Negative? : "+z1.getSign());
			System.out.println("No. of digits : "+z1.getDigitCount());
			
			System.out.println();
		}
		System.out.println();
		System.out.println("Comparisons : ");
		for(int i=0; i<9; i++)
		{
			z1=arr[i];
			x=alph[i];
			for(int j=0; j<9; j++)
			{
				z2=arr[j];
				y=alph[j];
				System.out.println(x+" equal to "+y+" : "+z1.equalTo(z2));
				System.out.println(x+" less than "+y+" : "+z1.lessThan(z2));
				System.out.println(x+" greater than "+y+" : "+z1.greaterThan(z2));
				
				System.out.println();
			}
		}
		// Execution time for comparison operations using SLLSimpleList
/*		A equal to A  
		Execution time : 90776
		A less than A  
		Execution time : 1114426
		A greater than A  
		Execution time : 133265

		A equal to B  
		Execution time : 72970
		A less than B  
		Execution time : 73445
		A greater than B  
		Execution time : 190797

		A equal to C  
		Execution time : 63774
		A less than C  
		Execution time : 145157
		A greater than C  
		Execution time : 65179

		A equal to D  
		Execution time : 64385
		A less than D  
		Execution time : 61892
		A greater than D  
		Execution time : 106964

		A equal to E  
		Execution time : 56629
		A less than E  
		Execution time : 53746
		A greater than E  
		Execution time : 52602

		A equal to F  
		Execution time : 222893
		A less than F  
		Execution time : 18782
		A greater than F  
		Execution time : 74716

		A equal to G  
		Execution time : 59690
		A less than G  
		Execution time : 55621
		A greater than G  
		Execution time : 86232

		A equal to H  
		Execution time : 56409
		A less than H  
		Execution time : 56735
		A greater than H  
		Execution time : 96007

		A equal to I  
		Execution time : 57311
		A less than I  
		Execution time : 56779
		A greater than I  
		Execution time : 67147

		B equal to A  
		Execution time : 57815
		B less than A  
		Execution time : 57559
		B greater than A  
		Execution time : 85699

		B equal to B  
		Execution time : 114721
		B less than B  
		Execution time : 14831
		B greater than B  
		Execution time : 49692

		B equal to C  
		Execution time : 17415
		B less than C  
		Execution time : 10762
		B greater than C  
		Execution time : 10566

		B equal to D  
		Execution time : 10792
		B less than D  
		Execution time : 76686
		B greater than D  
		Execution time : 76658

		B equal to E  
		Execution time : 71598
		B less than E  
		Execution time : 57073
		B greater than E  
		Execution time : 76008

		B equal to F  
		Execution time : 99642
		B less than F  
		Execution time : 91331
		B greater than F  
		Execution time : 60093

		B equal to G  
		Execution time : 65283
		B less than G  
		Execution time : 55320
		B greater than G  
		Execution time : 55045

		B equal to H  
		Execution time : 58041
		B less than H  
		Execution time : 55357
		B greater than H  
		Execution time : 55783

		B equal to I  
		Execution time : 50771
		B less than I  
		Execution time : 49464
		B greater than I  
		Execution time : 36709

		C equal to A  
		Execution time : 8444
		C less than A  
		Execution time : 7197
		C greater than A  
		Execution time : 7705

		C equal to B  
		Execution time : 7287
		C less than B  
		Execution time : 106889
		C greater than B  
		Execution time : 55107

		C equal to C  
		Execution time : 11545
		C less than C  
		Execution time : 9916
		C greater than C  
		Execution time : 9188

		C equal to D  
		Execution time : 8000
		C less than D  
		Execution time : 11232
		C greater than D  
		Execution time : 9045

		C equal to E  
		Execution time : 7553
		C less than E  
		Execution time : 8244
		C greater than E  
		Execution time : 37774

		C equal to F  
		Execution time : 7494
		C less than F  
		Execution time : 29159
		C greater than F  
		Execution time : 15103

		C equal to G  
		Execution time : 7073
		C less than G  
		Execution time : 6776
		C greater than G  
		Execution time : 7567

		C equal to H  
		Execution time : 8317
		C less than H  
		Execution time : 6917
		C greater than H  
		Execution time : 13993

		C equal to I  
		Execution time : 9188
		C less than I  
		Execution time : 7727
		C greater than I  
		Execution time : 8212

		D equal to A  
		Execution time : 7553
		D less than A  
		Execution time : 38216
		D greater than A  
		Execution time : 7942

		D equal to B  
		Execution time : 7718
		D less than B  
		Execution time : 7635
		D greater than B  
		Execution time : 18885

		D equal to C  
		Execution time : 7682
		D less than C  
		Execution time : 8211
		D greater than C  
		Execution time : 7545

		D equal to D  
		Execution time : 12659
		D less than D  
		Execution time : 7574
		D greater than D  
		Execution time : 7179

		D equal to E  
		Execution time : 7765
		D less than E  
		Execution time : 6885
		D greater than E  
		Execution time : 7659

		D equal to F  
		Execution time : 7391
		D less than F  
		Execution time : 12640
		D greater than F  
		Execution time : 17569

		D equal to G  
		Execution time : 8404
		D less than G  
		Execution time : 7760
		D greater than G  
		Execution time : 7825

		D equal to H  
		Execution time : 7999
		D less than H  
		Execution time : 74334
		D greater than H  
		Execution time : 44268

		D equal to I  
		Execution time : 12343
		D less than I  
		Execution time : 7921
		D greater than I  
		Execution time : 7863

		E equal to A  
		Execution time : 7146
		E less than A  
		Execution time : 8772
		E greater than A  
		Execution time : 7818

		E equal to B  
		Execution time : 7485
		E less than B  
		Execution time : 11274
		E greater than B  
		Execution time : 9352

		E equal to C  
		Execution time : 6660
		E less than C  
		Execution time : 6226
		E greater than C  
		Execution time : 8113

		E equal to D  
		Execution time : 7117
		E less than D  
		Execution time : 12400
		E greater than D  
		Execution time : 15652

		E equal to E  
		Execution time : 8077
		E less than E  
		Execution time : 8469
		E greater than E  
		Execution time : 13704

		E equal to F  
		Execution time : 9383
		E less than F  
		Execution time : 5620
		E greater than F  
		Execution time : 6494

		E equal to G  
		Execution time : 6164
		E less than G  
		Execution time : 7428
		E greater than G  
		Execution time : 7070

		E equal to H  
		Execution time : 6065
		E less than H  
		Execution time : 6282
		E greater than H  
		Execution time : 6607

		E equal to I  
		Execution time : 5871
		E less than I  
		Execution time : 6352
		E greater than I  
		Execution time : 6072

		F equal to A  
		Execution time : 11008
		F less than A  
		Execution time : 6860
		F greater than A  
		Execution time : 6804

		F equal to B  
		Execution time : 5222
		F less than B  
		Execution time : 22306
		F greater than B  
		Execution time : 8267

		F equal to C  
		Execution time : 11592
		F less than C  
		Execution time : 7129
		F greater than C  
		Execution time : 8448

		F equal to D  
		Execution time : 7177
		F less than D  
		Execution time : 9894
		F greater than D  
		Execution time : 10094

		F equal to E  
		Execution time : 9541
		F less than E  
		Execution time : 8625
		F greater than E  
		Execution time : 12468

		F equal to F  
		Execution time : 17712
		F less than F  
		Execution time : 7281
		F greater than F  
		Execution time : 9978

		F equal to G  
		Execution time : 6564
		F less than G  
		Execution time : 10693
		F greater than G  
		Execution time : 7666

		F equal to H  
		Execution time : 6602
		F less than H  
		Execution time : 7119
		F greater than H  
		Execution time : 7543

		F equal to I  
		Execution time : 5226
		F less than I  
		Execution time : 9505
		F greater than I  
		Execution time : 16193

		G equal to A  
		Execution time : 27802
		G less than A  
		Execution time : 7340
		G greater than A  
		Execution time : 7231

		G equal to B  
		Execution time : 6588
		G less than B  
		Execution time : 6459
		G greater than B  
		Execution time : 90975

		G equal to C  
		Execution time : 7890
		G less than C  
		Execution time : 65848
		G greater than C  
		Execution time : 9036

		G equal to D  
		Execution time : 6962
		G less than D  
		Execution time : 6794
		G greater than D  
		Execution time : 15002

		G equal to E  
		Execution time : 8040
		G less than E  
		Execution time : 6753
		G greater than E  
		Execution time : 8339

		G equal to F  
		Execution time : 31108
		G less than F  
		Execution time : 7596
		G greater than F  
		Execution time : 6712

		G equal to G  
		Execution time : 7166
		G less than G  
		Execution time : 6587
		G greater than G  
		Execution time : 7895

		G equal to H  
		Execution time : 6301
		G less than H  
		Execution time : 5882
		G greater than H  
		Execution time : 6380

		G equal to I  
		Execution time : 11115
		G less than I  
		Execution time : 6293
		G greater than I  
		Execution time : 6172

		H equal to A  
		Execution time : 9298
		H less than A  
		Execution time : 7010
		H greater than A  
		Execution time : 14793

		H equal to B  
		Execution time : 5914
		H less than B  
		Execution time : 11941
		H greater than B  
		Execution time : 6744

		H equal to C  
		Execution time : 10860
		H less than C  
		Execution time : 6218
		H greater than C  
		Execution time : 5892

		H equal to D  
		Execution time : 10934
		H less than D  
		Execution time : 12444
		H greater than D  
		Execution time : 7361

		H equal to E  
		Execution time : 6074
		H less than E  
		Execution time : 6550
		H greater than E  
		Execution time : 6355

		H equal to F  
		Execution time : 6026
		H less than F  
		Execution time : 5607
		H greater than F  
		Execution time : 6414

		H equal to G  
		Execution time : 6743
		H less than G  
		Execution time : 5586
		H greater than G  
		Execution time : 6755

		H equal to H  
		Execution time : 5966
		H less than H  
		Execution time : 6065
		H greater than H  
		Execution time : 6763

		H equal to I  
		Execution time : 7171
		H less than I  
		Execution time : 13985
		H greater than I  
		Execution time : 6320

		I equal to A  
		Execution time : 7481
		I less than A  
		Execution time : 11812
		I greater than A  
		Execution time : 12351

		I equal to B  
		Execution time : 6108
		I less than B  
		Execution time : 6349
		I greater than B  
		Execution time : 9361

		I equal to C  
		Execution time : 5738
		I less than C  
		Execution time : 6613
		I greater than C  
		Execution time : 7990

		I equal to D  
		Execution time : 7737
		I less than D  
		Execution time : 6732
		I greater than D  
		Execution time : 21229

		I equal to E  
		Execution time : 6370
		I less than E  
		Execution time : 6640
		I greater than E  
		Execution time : 6125

		I equal to F  
		Execution time : 14865
		I less than F  
		Execution time : 6312
		I greater than F  
		Execution time : 10629

		I equal to G  
		Execution time : 8153
		I less than G  
		Execution time : 5885
		I greater than G  
		Execution time : 7058

		I equal to H  
		Execution time : 12236
		I less than H  
		Execution time : 6499
		I greater than H  
		Execution time : 5863

		I equal to I  
		Execution time : 11909
		I less than I  
		Execution time : 6539
		I greater than I  
		Execution time : 11228*/
		
		// Execution time for comparison operations using ArraySimpleList
		/*A equal to A  
		Execution time : 153286
		A less than A  
		Execution time : 15853
		A greater than A  
		Execution time : 12487

		A equal to B  
		Execution time : 9688
		A less than B  
		Execution time : 8487
		A greater than B  
		Execution time : 9191

		A equal to C  
		Execution time : 9136
		A less than C  
		Execution time : 19438
		A greater than C  
		Execution time : 9586

		A equal to D  
		Execution time : 9673
		A less than D  
		Execution time : 9921
		A greater than D  
		Execution time : 23541

		A equal to E  
		Execution time : 11896
		A less than E  
		Execution time : 10831
		A greater than E  
		Execution time : 9829

		A equal to F  
		Execution time : 20696
		A less than F  
		Execution time : 10835
		A greater than F  
		Execution time : 25241

		A equal to G  
		Execution time : 36342
		A less than G  
		Execution time : 13173
		A greater than G  
		Execution time : 12624

		A equal to H  
		Execution time : 11251
		A less than H  
		Execution time : 13787
		A greater than H  
		Execution time : 15441

		A equal to I  
		Execution time : 11326
		A less than I  
		Execution time : 11431
		A greater than I  
		Execution time : 16918

		B equal to A  
		Execution time : 11214
		B less than A  
		Execution time : 11030
		B greater than A  
		Execution time : 11123

		B equal to B  
		Execution time : 11125
		B less than B  
		Execution time : 925597
		B greater than B  
		Execution time : 24343

		B equal to C  
		Execution time : 16527
		B less than C  
		Execution time : 12025
		B greater than C  
		Execution time : 12772

		B equal to D  
		Execution time : 12098
		B less than D  
		Execution time : 11214
		B greater than D  
		Execution time : 10651

		B equal to E  
		Execution time : 1946307
		B less than E  
		Execution time : 22107
		B greater than E  
		Execution time : 13806

		B equal to F  
		Execution time : 10082
		B less than F  
		Execution time : 8492
		B greater than F  
		Execution time : 8374

		B equal to G  
		Execution time : 17522
		B less than G  
		Execution time : 8055
		B greater than G  
		Execution time : 7706

		B equal to H  
		Execution time : 7151
		B less than H  
		Execution time : 8296
		B greater than H  
		Execution time : 7662

		B equal to I  
		Execution time : 7622
		B less than I  
		Execution time : 7938
		B greater than I  
		Execution time : 6840

		C equal to A  
		Execution time : 6785
		C less than A  
		Execution time : 6767
		C greater than A  
		Execution time : 6773

		C equal to B  
		Execution time : 7055
		C less than B  
		Execution time : 13747
		C greater than B  
		Execution time : 7163

		C equal to C  
		Execution time : 6206
		C less than C  
		Execution time : 7549
		C greater than C  
		Execution time : 6628

		C equal to D  
		Execution time : 6813
		C less than D  
		Execution time : 10967
		C greater than D  
		Execution time : 8022

		C equal to E  
		Execution time : 7348
		C less than E  
		Execution time : 7011
		C greater than E  
		Execution time : 7454

		C equal to F  
		Execution time : 7293
		C less than F  
		Execution time : 56055
		C greater than F  
		Execution time : 38165

		C equal to G  
		Execution time : 10109
		C less than G  
		Execution time : 7728
		C greater than G  
		Execution time : 8562

		C equal to H  
		Execution time : 8071
		C less than H  
		Execution time : 6299
		C greater than H  
		Execution time : 13403

		C equal to I  
		Execution time : 7194
		C less than I  
		Execution time : 6168
		C greater than I  
		Execution time : 6700

		D equal to A  
		Execution time : 6148
		D less than A  
		Execution time : 6639
		D greater than A  
		Execution time : 7235

		D equal to B  
		Execution time : 6578
		D less than B  
		Execution time : 5762
		D greater than B  
		Execution time : 30209

		D equal to C  
		Execution time : 6361
		D less than C  
		Execution time : 6139
		D greater than C  
		Execution time : 5898

		D equal to D  
		Execution time : 85794
		D less than D  
		Execution time : 13480
		D greater than D  
		Execution time : 35133

		D equal to E  
		Execution time : 904428
		D less than E  
		Execution time : 16467
		D greater than E  
		Execution time : 9250

		D equal to F  
		Execution time : 11738
		D less than F  
		Execution time : 111761
		D greater than F  
		Execution time : 9741

		D equal to G  
		Execution time : 7721
		D less than G  
		Execution time : 6843
		D greater than G  
		Execution time : 6848

		D equal to H  
		Execution time : 5783
		D less than H  
		Execution time : 121079
		D greater than H  
		Execution time : 12045

		D equal to I  
		Execution time : 7958
		D less than I  
		Execution time : 5993
		D greater than I  
		Execution time : 35487

		E equal to A  
		Execution time : 9725
		E less than A  
		Execution time : 6292
		E greater than A  
		Execution time : 7054

		E equal to B  
		Execution time : 6755
		E less than B  
		Execution time : 30234
		E greater than B  
		Execution time : 34091

		E equal to C  
		Execution time : 8497
		E less than C  
		Execution time : 170283
		E greater than C  
		Execution time : 18107

		E equal to D  
		Execution time : 14211
		E less than D  
		Execution time : 21675
		E greater than D  
		Execution time : 11740

		E equal to E  
		Execution time : 12269
		E less than E  
		Execution time : 11190
		E greater than E  
		Execution time : 12881

		E equal to F  
		Execution time : 5613
		E less than F  
		Execution time : 668677
		E greater than F  
		Execution time : 8260

		E equal to G  
		Execution time : 5799
		E less than G  
		Execution time : 13154
		E greater than G  
		Execution time : 5993

		E equal to H  
		Execution time : 6487
		E less than H  
		Execution time : 6124
		E greater than H  
		Execution time : 9555

		E equal to I  
		Execution time : 5585
		E less than I  
		Execution time : 19989
		E greater than I  
		Execution time : 31680

		F equal to A  
		Execution time : 12368
		F less than A  
		Execution time : 11322
		F greater than A  
		Execution time : 11786

		F equal to B  
		Execution time : 6285
		F less than B  
		Execution time : 5509
		F greater than B  
		Execution time : 7305

		F equal to C  
		Execution time : 9824
		F less than C  
		Execution time : 6060
		F greater than C  
		Execution time : 7596

		F equal to D  
		Execution time : 6963
		F less than D  
		Execution time : 5196
		F greater than D  
		Execution time : 6097

		F equal to E  
		Execution time : 5259
		F less than E  
		Execution time : 5771
		F greater than E  
		Execution time : 6161

		F equal to F  
		Execution time : 7053
		F less than F  
		Execution time : 5266
		F greater than F  
		Execution time : 6016

		F equal to G  
		Execution time : 5083
		F less than G  
		Execution time : 12107
		F greater than G  
		Execution time : 8693

		F equal to H  
		Execution time : 10165
		F less than H  
		Execution time : 5523
		F greater than H  
		Execution time : 6024

		F equal to I  
		Execution time : 6560
		F less than I  
		Execution time : 9434
		F greater than I  
		Execution time : 6635

		G equal to A  
		Execution time : 9625
		G less than A  
		Execution time : 9867
		G greater than A  
		Execution time : 5809

		G equal to B  
		Execution time : 5116
		G less than B  
		Execution time : 5849
		G greater than B  
		Execution time : 9862

		G equal to C  
		Execution time : 5721
		G less than C  
		Execution time : 5254
		G greater than C  
		Execution time : 11633

		G equal to D  
		Execution time : 5857
		G less than D  
		Execution time : 8443
		G greater than D  
		Execution time : 15194

		G equal to E  
		Execution time : 6396
		G less than E  
		Execution time : 6411
		G greater than E  
		Execution time : 10793

		G equal to F  
		Execution time : 6070
		G less than F  
		Execution time : 5836
		G greater than F  
		Execution time : 9739

		G equal to G  
		Execution time : 12849
		G less than G  
		Execution time : 5892
		G greater than G  
		Execution time : 6339

		G equal to H  
		Execution time : 7579
		G less than H  
		Execution time : 5445
		G greater than H  
		Execution time : 5602

		G equal to I  
		Execution time : 10852
		G less than I  
		Execution time : 5818
		G greater than I  
		Execution time : 6011

		H equal to A  
		Execution time : 5599
		H less than A  
		Execution time : 5923
		H greater than A  
		Execution time : 5928

		H equal to B  
		Execution time : 5515
		H less than B  
		Execution time : 5500
		H greater than B  
		Execution time : 11924

		H equal to C  
		Execution time : 5216
		H less than C  
		Execution time : 6090
		H greater than C  
		Execution time : 6383

		H equal to D  
		Execution time : 4568
		H less than D  
		Execution time : 11393
		H greater than D  
		Execution time : 5501

		H equal to E  
		Execution time : 7346
		H less than E  
		Execution time : 8280
		H greater than E  
		Execution time : 5756

		H equal to F  
		Execution time : 7196
		H less than F  
		Execution time : 5851
		H greater than F  
		Execution time : 5972

		H equal to G  
		Execution time : 5082
		H less than G  
		Execution time : 5932
		H greater than G  
		Execution time : 9924

		H equal to H  
		Execution time : 5704
		H less than H  
		Execution time : 5627
		H greater than H  
		Execution time : 6875

		H equal to I  
		Execution time : 11998
		H less than I  
		Execution time : 5263
		H greater than I  
		Execution time : 5487

		I equal to A  
		Execution time : 6449
		I less than A  
		Execution time : 5729
		I greater than A  
		Execution time : 10109

		I equal to B  
		Execution time : 6760
		I less than B  
		Execution time : 5619
		I greater than B  
		Execution time : 7387

		I equal to C  
		Execution time : 6759
		I less than C  
		Execution time : 10374
		I greater than C  
		Execution time : 10204

		I equal to D  
		Execution time : 6919
		I less than D  
		Execution time : 10541
		I greater than D  
		Execution time : 7311

		I equal to E  
		Execution time : 5508
		I less than E  
		Execution time : 6501
		I greater than E  
		Execution time : 6326

		I equal to F  
		Execution time : 9496
		I less than F  
		Execution time : 10692
		I greater than F  
		Execution time : 6036

		I equal to G  
		Execution time : 5493
		I less than G  
		Execution time : 6399
		I greater than G  
		Execution time : 6392

		I equal to H  
		Execution time : 9020
		I less than H  
		Execution time : 5108
		I greater than H  
		Execution time : 5280

		I equal to I  
		Execution time : 5147
		I less than I  
		Execution time : 5457
		I greater than I  
		Execution time : 6292*/
		
		int a=2222;
		int b=99999999;
		
		System.out.println("Overflow digits in a are "+UtilityOperations.overflow(a));
		System.out.println("Underflow digits in a are "+UtilityOperations.underflow(a));
		System.out.println("Number of digits in a are "+UtilityOperations.digits(a));

		System.out.println("Overflow digits in b are "+UtilityOperations.overflow(b));
		System.out.println("Underflow digits in b are "+UtilityOperations.underflow(b));
		System.out.println("Number of digits in b are "+UtilityOperations.digits(b));
		//SLL=797028, Array=68087
		
		
		System.out.println("\n \n");
		System.out.println("Step 2 Test Cases:");
		System.out.println("1) Addition : ");
		for(int i=0; i<9; i++)
		{
			z1=arr[i];
			x=alph[i];
			for(int j=0; j<9; j++)
			{
				z2=arr[j];
				y=alph[j];
				System.out.print(x+" + "+y+" = ");
				z1.add(z2).output();
				
				System.out.println("\n");
			}
		}
		//Execution time for addition test cases using SLLSimpleList
		/*		Execution time for A + A = 6520
				Execution time for A + B = 5561
				Execution time for A + C = 13530
				Execution time for A + D = 4015
				Execution time for A + E = 4425
				Execution time for A + F = 13924
				Execution time for A + G = 6446
				Execution time for A + H = 13656
				Execution time for A + I = 13352
				Execution time for B + A = 2924
				Execution time for B + B = 1886
				Execution time for B + C = 10328
				Execution time for B + D = 2929
				Execution time for B + E = 4149
				Execution time for B + F = 9648
				Execution time for B + G = 5845
				Execution time for B + H = 14761
				Execution time for B + I = 16085
				Execution time for C + A = 9495
				Execution time for C + B = 8034
				Execution time for C + C = 5243
				Execution time for C + D = 20654
				Execution time for C + E = 20529
				Execution time for C + F = 8499
				Execution time for C + G = 17962
				Execution time for C + H = 10568
				Execution time for C + I = 23130
				Execution time for D + A = 3157
				Execution time for D + B = 2580
				Execution time for D + C = 7956
				Execution time for D + D = 3108
				Execution time for D + E = 4138
				Execution time for D + F = 9827
				Execution time for D + G = 6308
				Execution time for D + H = 13484
				Execution time for D + I = 16441
				Execution time for E + A = 3833
				Execution time for E + B = 3611
				Execution time for E + C = 9056
				Execution time for E + D = 6156
				Execution time for E + E = 8747
				Execution time for E + F = 29861
				Execution time for E + G = 6767
				Execution time for E + H = 15787
				Execution time for E + I = 16483
				Execution time for F + A = 9099
				Execution time for F + B = 16181
				Execution time for F + C = 5264
				Execution time for F + D = 9848
				Execution time for F + E = 15427
				Execution time for F + F = 9118
				Execution time for F + G = 13400
				Execution time for F + H = 13720
				Execution time for F + I = 27975
				Execution time for G + A = 10840
				Execution time for G + B = 7120
				Execution time for G + C = 13478
				Execution time for G + D = 10954
				Execution time for G + E = 8877
				Execution time for G + F = 15412
				Execution time for G + G = 7830
				Execution time for G + H = 22049
				Execution time for G + I = 15444
				Execution time for H + A = 13638
				Execution time for H + B = 20976
				Execution time for H + C = 9479
				Execution time for H + D = 14485
				Execution time for H + E = 16767
				Execution time for H + F = 13648
				Execution time for H + G = 18050
				Execution time for H + H = 12627
				Execution time for H + I = 30287
				Execution time for I + A = 14632
				Execution time for I + B = 16740
				Execution time for I + C = 21742
				Execution time for I + D = 14099
				Execution time for I + E = 18814
				Execution time for I + F = 34124
				Execution time for I + G = 18849
				Execution time for I + H = 26960
				Execution time for I + I = 18791*/
				
		//Execution time for addition test cases using ArraySimpleList
		/*		Execution time for A + A = 9479
				Execution time for A + B = 5098
				Execution time for A + C = 12068
				Execution time for A + D = 46543
				Execution time for A + E = 9104
				Execution time for A + F = 15162
				Execution time for A + G = 13278
				Execution time for A + H = 11702
				Execution time for A + I = 15376
				Execution time for B + A = 3773
				Execution time for B + B = 3004
				Execution time for B + C = 22543
				Execution time for B + D = 4417
				Execution time for B + E = 5306
				Execution time for B + F = 15239
				Execution time for B + G = 8152
				Execution time for B + H = 12305
				Execution time for B + I = 66423
				Execution time for C + A = 20877
				Execution time for C + B = 8561
				Execution time for C + C = 5737
				Execution time for C + D = 12080
				Execution time for C + E = 10049
				Execution time for C + F = 7133
				Execution time for C + G = 16230
				Execution time for C + H = 13559
				Execution time for C + I = 19814
				Execution time for D + A = 4508
				Execution time for D + B = 4080
				Execution time for D + C = 7741
				Execution time for D + D = 4043
				Execution time for D + E = 5893
				Execution time for D + F = 9373
				Execution time for D + G = 8066
				Execution time for D + H = 11218
				Execution time for D + I = 21356
				Execution time for E + A = 5957
				Execution time for E + B = 5558
				Execution time for E + C = 9648
				Execution time for E + D = 5750
				Execution time for E + E = 5604
				Execution time for E + F = 22290
				Execution time for E + G = 13038
				Execution time for E + H = 14244
				Execution time for E + I = 17791
				Execution time for F + A = 8078
				Execution time for F + B = 17107
				Execution time for F + C = 7210
				Execution time for F + D = 8376
				Execution time for F + E = 13635
				Execution time for F + F = 6500
				Execution time for F + G = 12090
				Execution time for F + H = 10803
				Execution time for F + I = 17967
				Execution time for G + A = 8711
				Execution time for G + B = 14739
				Execution time for G + C = 11438
				Execution time for G + D = 8962
				Execution time for G + E = 14699
				Execution time for G + F = 12916
				Execution time for G + G = 8407
				Execution time for G + H = 15657
				Execution time for G + I = 17007
				Execution time for H + A = 15651
				Execution time for H + B = 16208
				Execution time for H + C = 9467
				Execution time for H + D = 15342
				Execution time for H + E = 13381
				Execution time for H + F = 8986
				Execution time for H + G = 18789
				Execution time for H + H = 9536
				Execution time for H + I = 24387
				Execution time for I + A = 16505
				Execution time for I + B = 24272
				Execution time for I + C = 16833
				Execution time for I + D = 16013
				Execution time for I + E = 20746
				Execution time for I + F = 19630
				Execution time for I + G = 28817
				Execution time for I + H = 36504
				Execution time for I + I = 20870*/
		
		System.out.println();
		System.out.println("2) Subtraction : ");
		for(int k=0; k<9; k++)
		{
			z1=arr[k];
			x=alph[k];
			for(int j=0; j<9; j++)
			{
				z2=arr[j];
				y=alph[j];
				
				System.out.print(x+" - "+y+" = ");
				z1.subtract(z2).output();
				System.out.println("\n");
			}
		}
		//Execution time of Subtraction function for SLLSimpleList
		/*		Execution time for A - A = 21532
				Execution time for A - B = 524916
				Execution time for A - C = 20065
				Execution time for A - D = 5313
				Execution time for A - E = 5948
				Execution time for A - F = 7371
				Execution time for A - G = 7676
				Execution time for A - H = 5236
				Execution time for A - I = 12750
				Execution time for B - A = 3243
				Execution time for B - B = 19685
				Execution time for B - C = 3411
				Execution time for B - D = 4395
				Execution time for B - E = 19676
				Execution time for B - F = 6659
				Execution time for B - G = 8380
				Execution time for B - H = 4764
				Execution time for B - I = 12276
				Execution time for C - A = 11670
				Execution time for C - B = 3353
				Execution time for C - C = 915939
				Execution time for C - D = 16564
				Execution time for C - E = 4978
				Execution time for C - F = 7302
				Execution time for C - G = 11412
				Execution time for C - H = 7981
				Execution time for C - I = 8938
				Execution time for D - A = 4146
				Execution time for D - B = 3998
				Execution time for D - C = 3477
				Execution time for D - D = 269347
				Execution time for D - E = 9265
				Execution time for D - F = 4609
				Execution time for D - G = 7956
				Execution time for D - H = 145313
				Execution time for D - I = 17236
				Execution time for E - A = 5872
				Execution time for E - B = 9813
				Execution time for E - C = 4204
				Execution time for E - D = 244141
				Execution time for E - E = 45864
				Execution time for E - F = 5642
				Execution time for E - G = 14451
				Execution time for E - H = 5691
				Execution time for E - I = 1866539
				Execution time for F - A = 39461
				Execution time for F - B = 11316
				Execution time for F - C = 318606
				Execution time for F - D = 18890
				Execution time for F - E = 19795
				Execution time for F - F = 27755
				Execution time for F - G = 10402
				Execution time for F - H = 7577
				Execution time for F - I = 7001
				Execution time for G - A = 8538
				Execution time for G - B = 5655
				Execution time for G - C = 3952
				Execution time for G - D = 9443
				Execution time for G - E = 9794
				Execution time for G - F = 3336
				Execution time for G - G = 33311
				Execution time for G - H = 5269
				Execution time for G - I = 21940
				Execution time for H - A = 4893
				Execution time for H - B = 3746
				Execution time for H - C = 9538
				Execution time for H - D = 4376
				Execution time for H - E = 4116
				Execution time for H - F = 5943
				Execution time for H - G = 8406
				Execution time for H - H = 43712
				Execution time for H - I = 9560
				Execution time for I - A = 13750
				Execution time for I - B = 10648
				Execution time for I - C = 9382
				Execution time for I - D = 11530
				Execution time for I - E = 12769
				Execution time for I - F = 6993
				Execution time for I - G = 14698
				Execution time for I - H = 9446
				Execution time for I - I = 98247*/

		//Execution time of Subtraction function for ArraySimpleList
		/*		Execution time for A - A = 21159
				Execution time for A - B = 6499
				Execution time for A - C = 7792
				Execution time for A - D = 6228
				Execution time for A - E = 7063
				Execution time for A - F = 7381
				Execution time for A - G = 204432
				Execution time for A - H = 13745
				Execution time for A - I = 20952
				Execution time for B - A = 6267
				Execution time for B - B = 21354
				Execution time for B - C = 7749
				Execution time for B - D = 23070
				Execution time for B - E = 8322
				Execution time for B - F = 7929
				Execution time for B - G = 9779
				Execution time for B - H = 12013
				Execution time for B - I = 22934
				Execution time for C - A = 8089
				Execution time for C - B = 7123
				Execution time for C - C = 23096
				Execution time for C - D = 9929
				Execution time for C - E = 10517
				Execution time for C - F = 7554
				Execution time for C - G = 15843
				Execution time for C - H = 10375
				Execution time for C - I = 21858
				Execution time for D - A = 6813
				Execution time for D - B = 6363
				Execution time for D - C = 7897
				Execution time for D - D = 21986
				Execution time for D - E = 9766
				Execution time for D - F = 8962
				Execution time for D - G = 12795
				Execution time for D - H = 11594
				Execution time for D - I = 22689
				Execution time for E - A = 7455
				Execution time for E - B = 6733
				Execution time for E - C = 12498
				Execution time for E - D = 10959
				Execution time for E - E = 28690
				Execution time for E - F = 9811
				Execution time for E - G = 14627
				Execution time for E - H = 22446
				Execution time for E - I = 22002
				Execution time for F - A = 8354
				Execution time for F - B = 7994
				Execution time for F - C = 7276
				Execution time for F - D = 8052
				Execution time for F - E = 10383
				Execution time for F - F = 25017
				Execution time for F - G = 15607
				Execution time for F - H = 14226
				Execution time for F - I = 21550
				Execution time for G - A = 11530
				Execution time for G - B = 19326
				Execution time for G - C = 11461
				Execution time for G - D = 13356
				Execution time for G - E = 10945
				Execution time for G - F = 11497
				Execution time for G - G = 43404
				Execution time for G - H = 14773
				Execution time for G - I = 26363
				Execution time for H - A = 14555
				Execution time for H - B = 14192
				Execution time for H - C = 13462
				Execution time for H - D = 11521
				Execution time for H - E = 11343
				Execution time for H - F = 13941
				Execution time for H - G = 12831
				Execution time for H - H = 39788
				Execution time for H - I = 29347
				Execution time for I - A = 19583
				Execution time for I - B = 16472
				Execution time for I - C = 23967
				Execution time for I - D = 16784
				Execution time for I - E = 21928
				Execution time for I - F = 23116
				Execution time for I - G = 23214
				Execution time for I - H = 23124
				Execution time for I - I = 65477*/
		
		System.out.println();
		System.out.println("3) Multiplication : ");
		for(int j=0; j<9; j++)
		{
			z1=arr[j];
			x=alph[j];
			for(int k=0; k<9; k++)
			{
				z2=arr[k];
				y=alph[k];
				
				System.out.print(x+" * "+y+" = ");
				z1.multiply(z2).output();
				System.out.println("\n");
			}
		}
		//Execution time of Multiplication function for SLLSimpleList
		/*		Execution time for A * A = 11779
				Execution time for A * B = 29466
				Execution time for A * C = 21908
				Execution time for A * D = 16320
				Execution time for A * E = 24531
				Execution time for A * F = 13649
				Execution time for A * G = 59046
				Execution time for A * H = 73885
				Execution time for A * I = 296084
				Execution time for B * A = 6846
				Execution time for B * B = 6275
				Execution time for B * C = 7172
				Execution time for B * D = 9299
				Execution time for B * E = 26686
				Execution time for B * F = 14403
				Execution time for B * G = 64439
				Execution time for B * H = 61209
				Execution time for B * I = 331535
				Execution time for C * A = 6881
				Execution time for C * B = 63641
				Execution time for C * C = 10334
				Execution time for C * D = 14097
				Execution time for C * E = 34183
				Execution time for C * F = 13349
				Execution time for C * G = 71975
				Execution time for C * H = 58575
				Execution time for C * I = 327358
				Execution time for D * A = 7381
				Execution time for D * B = 7699
				Execution time for D * C = 12352
				Execution time for D * D = 13437
				Execution time for D * E = 37222
				Execution time for D * F = 15825
				Execution time for D * G = 896001
				Execution time for D * H = 96896
				Execution time for D * I = 298788
				Execution time for E * A = 11403
				Execution time for E * B = 10918
				Execution time for E * C = 16716
				Execution time for E * D = 23177
				Execution time for E * E = 57523
				Execution time for E * F = 29283
				Execution time for E * G = 128679
				Execution time for E * H = 111103
				Execution time for E * I = 460114
				Execution time for F * A = 15842
				Execution time for F * B = 13038
				Execution time for F * C = 10442
				Execution time for F * D = 18186
				Execution time for F * E = 38268
				Execution time for F * F = 23649
				Execution time for F * G = 127186
				Execution time for F * H = 74354
				Execution time for F * I = 353619
				Execution time for G * A = 15401
				Execution time for G * B = 15159
				Execution time for G * C = 23400
				Execution time for G * D = 38824
				Execution time for G * E = 96200
				Execution time for G * F = 47198
				Execution time for G * G = 177189
				Execution time for G * H = 168611
				Execution time for G * I = 649522
				Execution time for H * A = 15757
				Execution time for H * B = 18808
				Execution time for H * C = 23762
				Execution time for H * D = 39107
				Execution time for H * E = 95310
				Execution time for H * F = 46159
				Execution time for H * G = 178534
				Execution time for H * H = 165999
				Execution time for H * I = 575636
				Execution time for I * A = 26120
				Execution time for I * B = 36291
				Execution time for I * C = 54754
				Execution time for I * D = 110203
				Execution time for I * E = 215026
				Execution time for I * F = 110469
				Execution time for I * G = 401441
				Execution time for I * H = 375912
				Execution time for I * I = 1191780*/
		
		//Execution time of Multiplication function for ArraySimpleList
		/*		Execution time for A * A = 14078
				Execution time for A * B = 14564
				Execution time for A * C = 20752
				Execution time for A * D = 21636
				Execution time for A * E = 66289
				Execution time for A * F = 31359
				Execution time for A * G = 160067
				Execution time for A * H = 146308
				Execution time for A * I = 891832
				Execution time for B * A = 17145
				Execution time for B * B = 12231
				Execution time for B * C = 17952
				Execution time for B * D = 22792
				Execution time for B * E = 50423
				Execution time for B * F = 25427
				Execution time for B * G = 117957
				Execution time for B * H = 104503
				Execution time for B * I = 583365
				Execution time for C * A = 10674
				Execution time for C * B = 10019
				Execution time for C * C = 11220
				Execution time for C * D = 18201
				Execution time for C * E = 61886
				Execution time for C * F = 21309
				Execution time for C * G = 148801
				Execution time for C * H = 93698
				Execution time for C * I = 607680
				Execution time for D * A = 24955
				Execution time for D * B = 14796
				Execution time for D * C = 17726
				Execution time for D * D = 26240
				Execution time for D * E = 70630
				Execution time for D * F = 34882
				Execution time for D * G = 128135
				Execution time for D * H = 106980
				Execution time for D * I = 662740
				Execution time for E * A = 39257
				Execution time for E * B = 37531
				Execution time for E * C = 44424
				Execution time for E * D = 56839
				Execution time for E * E = 86340
				Execution time for E * F = 41525
				Execution time for E * G = 250728
				Execution time for E * H = 147957
				Execution time for E * I = 747792
				Execution time for F * A = 21982
				Execution time for F * B = 15343
				Execution time for F * C = 16809
				Execution time for F * D = 28122
				Execution time for F * E = 52756
				Execution time for F * F = 35177
				Execution time for F * G = 116120
				Execution time for F * H = 147243
				Execution time for F * I = 15719803
				Execution time for G * A = 889113
				Execution time for G * B = 41679
				Execution time for G * C = 41880
				Execution time for G * D = 57236
				Execution time for G * E = 132233
				Execution time for G * F = 65843
				Execution time for G * G = 264290
				Execution time for G * H = 282859
				Execution time for G * I = 986239
				Execution time for H * A = 24506
				Execution time for H * B = 25609
				Execution time for H * C = 33508
				Execution time for H * D = 51215
				Execution time for H * E = 126444
				Execution time for H * F = 57875
				Execution time for H * G = 242204
				Execution time for H * H = 223731
				Execution time for H * I = 908088
				Execution time for I * A = 36411
				Execution time for I * B = 47547
				Execution time for I * C = 68884
				Execution time for I * D = 137006
				Execution time for I * E = 260807
				Execution time for I * F = 130831
				Execution time for I * G = 897598
				Execution time for I * H = 960139
				Execution time for I * I = 2320741*/
		
		System.out.println();
		System.out.println("4) Power : ");
		for(int l=0; l<9; l++)
		{
			z1=arr[l];
			
			System.out.print(alph[l]+" ^ 5 = ");
			z1.power(5).output();
			System.out.println("\n");
			System.out.print(alph[l]+" ^ 10 = ");
			z1.power(10).output();
			System.out.println("\n");
			System.out.print(alph[l]+" ^ 20 = ");
			z1.power(20).output();
			System.out.println("\n");
			System.out.print(alph[l]+" ^ 30 = ");
			z1.power(30).output();
			System.out.println("\n");
		}
		
		
		//Execution time of Power function for SLLSimpleList
		/*		Execution time for A ^ 5 = 43388
				Execution time for A ^ 10 = 60802
				Execution time for A ^ 20 = 119718
				Execution time for A ^ 30 = 161056
				Execution time for B ^ 5 = 10517
				Execution time for B ^ 10 = 92934
				Execution time for B ^ 20 = 249714
				Execution time for B ^ 30 = 537178
				Execution time for C ^ 5 = 11416
				Execution time for C ^ 10 = 146468
				Execution time for C ^ 20 = 514357
				Execution time for C ^ 30 = 1204488
				Execution time for D ^ 5 = 27002
				Execution time for D ^ 10 = 367108
				Execution time for D ^ 20 = 1029556
				Execution time for D ^ 30 = 2370106
				Execution time for E ^ 5 = 47403
				Execution time for E ^ 10 = 1155677
				Execution time for E ^ 20 = 5706467
				Execution time for E ^ 30 = 32192239
				Execution time for F ^ 5 = 18541
				Execution time for F ^ 10 = 197964
				Execution time for F ^ 20 = 1016731
				Execution time for F ^ 30 = 1827789
				Execution time for G ^ 5 = 29052
				Execution time for G ^ 10 = 2668003
				Execution time for G ^ 20 = 35145496
				Execution time for G ^ 30 = 26064313
				Execution time for H ^ 5 = 56422
				Execution time for H ^ 10 = 1114837
				Execution time for H ^ 20 = 16786362
				Execution time for H ^ 30 = 5452767
				Execution time for I ^ 5 = 32517
				Execution time for I ^ 10 = 3520435
				Execution time for I ^ 20 = 10123767
				Execution time for I ^ 30 = 64539628*/
		
		//Execution time of Power function for ArraySimpleList
		/*		Execution time for A ^ 5 = 71311
				Execution time for A ^ 10 = 186239
				Execution time for A ^ 20 = 206885
				Execution time for A ^ 30 = 339702
				Execution time for B ^ 5 = 37214
				Execution time for B ^ 10 = 459131
				Execution time for B ^ 20 = 4314788
				Execution time for B ^ 30 = 761201
				Execution time for C ^ 5 = 13833
				Execution time for C ^ 10 = 16896442
				Execution time for C ^ 20 = 1792618
				Execution time for C ^ 30 = 1348519
				Execution time for D ^ 5 = 23288
				Execution time for D ^ 10 = 277038
				Execution time for D ^ 20 = 1032674
				Execution time for D ^ 30 = 4473266
				Execution time for E ^ 5 = 117249
				Execution time for E ^ 10 = 1692824
				Execution time for E ^ 20 = 9159906
				Execution time for E ^ 30 = 50981927
				Execution time for F ^ 5 = 26853
				Execution time for F ^ 10 = 824396
				Execution time for F ^ 20 = 15873941
				Execution time for F ^ 30 = 6199963
				Execution time for G ^ 5 = 83954
				Execution time for G ^ 10 = 7050669
				Execution time for G ^ 20 = 40869212
				Execution time for G ^ 30 = 83657491
				Execution time for H ^ 5 = 37638
				Execution time for H ^ 10 = 2173076
				Execution time for H ^ 20 = 12760631
				Execution time for H ^ 30 = 37215700
				Execution time for I ^ 5 = 177787
				Execution time for I ^ 10 = 26266289
				Execution time for I ^ 20 = 187255774
				Execution time for I ^ 30 = 1059364307*/
				
		System.out.println();
		System.out.println("5)");
		char val='J';
		for(int m=0; m<17; m++)
		{
			z1=arr2[m];
			System.out.print(val+" = ");
			z1.output();
			System.out.println();
			val++;
		}
		
	}

}
